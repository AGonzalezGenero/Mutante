function isMutant(dna) {
    const n = dna.length;
    let mutantSequences = 0;

    // Verificar secuencia horizontal y vertical
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            if (j <= n - 4 && checkSequence(dna, i, j, 0, 1)) mutantSequences++; // Horizontal
            if (i <= n - 4 && checkSequence(dna, i, j, 1, 0)) mutantSequences++; // Vertical
            if (i <= n - 4 && j <= n - 4 && checkSequence(dna, i, j, 1, 1)) mutantSequences++; // Diagonal principal
            if (i <= n - 4 && j >= 3 && checkSequence(dna, i, j, 1, -1)) mutantSequences++; // Diagonal inversa

            if (mutantSequences > 1) return true; // Detener si encontramos más de una secuencia
        }
    }
    return false;
}

// Verifica una secuencia de cuatro letras iguales en una dirección
function checkSequence(dna, row, col, rowDir, colDir) {
    const char = dna[row][col];
    for (let k = 1; k < 4; k++) {
        if (dna[row + k * rowDir][col + k * colDir] !== char) return false;
    }
    return true;
}

module.exports = { isMutant };
