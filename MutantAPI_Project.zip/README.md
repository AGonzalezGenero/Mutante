# MutantAPI

## Descripción
Este proyecto implementa una API REST que detecta si una secuencia de ADN pertenece a un mutante. Además, almacena las secuencias en una base de datos y expone estadísticas sobre las verificaciones realizadas.

## Requisitos
- Node.js >= 14.x
- MySQL

## Instalación

1. Clona este repositorio.
2. Instala las dependencias:
   ```bash
   npm install
   ```

3. Configura la base de datos en MySQL ejecutando el siguiente script:
   ```sql
   CREATE DATABASE MutantDB;

   USE MutantDB;

   CREATE TABLE DNARecords (
       id INT AUTO_INCREMENT PRIMARY KEY,
       sequence VARCHAR(255) UNIQUE NOT NULL,
       is_mutant BOOLEAN NOT NULL
   );
   ```

4. Actualiza las credenciales de la base de datos en `index.js`.

## Uso

1. Inicia el servidor:
   ```bash
   node index.js
   ```

2. Usa Postman o `curl` para interactuar con los endpoints.

## Endpoints

### Verificar ADN
- **POST** `/mutant`
  - Cuerpo: 
    ```json
    { "dna": ["ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"] }
    ```
  - Respuestas:
    - 200 OK: Es mutante.
    - 403 Forbidden: No es mutante.

### Obtener estadísticas
- **GET** `/stats`
  - Respuesta:
    ```json
    { "count_mutant_dna": 40, "count_human_dna": 100, "ratio": 0.4 }
    ```
