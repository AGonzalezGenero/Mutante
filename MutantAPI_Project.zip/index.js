const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mysql = require("mysql2");
const { isMutant } = require("./mutantChecker");

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Conexión con la base de datos
const db = mysql.createConnection({
    host: "localhost",
    user: "tu_usuario",
    password: "tu_contraseña",
    database: "MutantDB",
});

db.connect((err) => {
    if (err) throw err;
    console.log("Conectado a la base de datos MySQL");
});

// Guardar o verificar ADN en la base de datos
const saveDna = (dna, isMutant, callback) => {
    const sequence = dna.join("");
    const sql = "INSERT INTO DNARecords (sequence, is_mutant) VALUES (?, ?) ON DUPLICATE KEY UPDATE id=id";
    db.query(sql, [sequence, isMutant], callback);
};

// Ruta principal para verificar ADN
app.post("/mutant", (req, res) => {
    const { dna } = req.body;

    if (!dna || !Array.isArray(dna) || !dna.length) {
        return res.status(400).send("Formato de ADN inválido");
    }

    const isMutantResult = isMutant(dna);
    saveDna(dna, isMutantResult, (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error al guardar el ADN");
        }

        if (isMutantResult) {
            return res.status(200).send("Mutante detectado");
        } else {
            return res.status(403).send("Humano no mutante");
        }
    });
});

// Ruta de estadísticas
app.get("/stats", (req, res) => {
    const sql = `
        SELECT 
            SUM(CASE WHEN is_mutant = 1 THEN 1 ELSE 0 END) AS count_mutant_dna,
            SUM(CASE WHEN is_mutant = 0 THEN 1 ELSE 0 END) AS count_human_dna,
            (SUM(CASE WHEN is_mutant = 1 THEN 1 ELSE 0 END) /
             SUM(CASE WHEN is_mutant = 0 THEN 1 ELSE 0 END)) AS ratio
        FROM DNARecords;
    `;
    db.query(sql, (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error al obtener estadísticas");
        }
        res.json(result[0]);
    });
});

// Ruta de prueba
app.get("/", (req, res) => {
    res.send("API Mutante funcionando");
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
